<?php

function debug($data){
    echo '<pre>' . print_r($data, return:1) . '</pre>';
}

function load($data) {
    foreach ($_POST as $k => $v) {
        if (array_key_exists($k, $data)) {
            $data[$k]['value'] = trim($v);
        }
    }
    return $data;
}

function validate($data) {
    $errors = '';
    foreach ($data as $k => $v) {
        if ($data[$k]['requiered']  && empty($data[$k]['value'])) {
            $errors .= "<li>Вы не заполнили поле {$data[$k]['field_name']}</li>";
        }
    }
    return $errors;
}

function get_adress($arr) {
    $txt = '';
    $additional_adress_data = ['', ' обл.', ' р-н', '', '', ' ул.', ' д.', ' кв.', ' дом.тел. ', ' моб.тел. '];
    for ($i = 0; $i < count($arr); $i++)
    {
        if ($i == 1 && $arr[$i] != 'choose_region')
        {
            $txt .= $arr[$i] . $additional_adress_data[$i] . ', ';
        }
        if ($i == 2 && $arr[$i] != '')
        {
            $txt .= $arr[$i] . $additional_adress_data[$i] . ', ';
        }
        if ($i == 8 && $arr[$i] != '')
        {
            $txt .= $additional_adress_data[$i] . $arr[$i] . ', ';
        }
        if ($i == 9 && $arr[$i] != '')
        {
            $txt .= $additional_adress_data[$i] . $arr[$i];
        }
        if ($i == 3 && $arr[$i] != '')
        {
            if ($arr[$i + 1] == 'город' || $arr[$i + 1] == 'деревня' || $arr[$i + 1] == 'село')
            {
                $txt .= $arr[$i + 1][0] . $arr[$i + 1][1] . ". " .  $arr[$i] . ', ';
            }
            if ($arr[$i + 1] == 'агрогородок')
            {
                $txt .= ' аг. ' . $arr[$i] . ', ';
            }
            if ($arr[$i + 1] == 'городской поселок')
            {
                $txt .= ' гп. ' . $arr[$i] . ', ';
            }
            $i++;
        }
        elseif ($i != 1 && $i != 2 && $i !=3 && $i != 9 && $i != 8 && $arr[$i] != '')
        {
            $txt .= $additional_adress_data[$i] . $arr[$i] . ', ';
        }
    }
    return $txt;
}

function get_passport_data($arr) {
    $txt = '';
    $additional_passport_data = ['', '', '', 'выдан ', '', '№' ];
    for ($i = 0; $i < count($arr); $i++)
    {
        if ($i == 2 || $i == 4)
        {
            $txt .= $additional_passport_data[$i] . $arr[$i] . ', ';
        }
        else
        {
            $txt .= $additional_passport_data[$i] . $arr[$i] . ' ';
        }
    }
    return $txt;
}

function data_dogovor($arr) {
    $contract_data = ['payment', 'term', 'price'];

    $contract_data[1] = '3 года 7 месяцев';

    if ($arr[2] == 'за счет средств республиканского бюджета')
    {
        $contract_data[0] = 'за счет средств республиканского (местного) бюджета';
        $contract_data[2] = '12710,19 (двенадцать тысяч семьсот десять рублей 19 копеек)';
    }
    else 
    {
        $contract_data[0] = $arr[2];
        $contract_data[2] = '2385,00 (две тысячи триста восемьдесят пять рублей 00 копеек)';
    }

    if ($arr[0] == '«Строительство зданий и сооружений»')
    {
        $contract_data[1] = '3 года 6 месяцев';
        if ($contract_data[0] == 'за счет средств республиканского бюджета')
        {
            $contract_data[2] = '12414,61 (двенадцать тысяч четыреста четырнадцать рублей 61 копейка)';
        }
    }

    elseif ($arr[0] == '«Технологическое обеспечение машиностроительного производства»' && $arr[1] == 'второй')
    {
        $contract_data[1] = '2 года 7 месяцев';
        if ($contract_data[0] == 'за счет средств республиканского бюджета')
        {
            $contract_data[2] = '9163,16 (девять тысяч сто шестьдесят три рубля 16 копеек)';
        }
    }

    elseif ($arr[0] == '«Производство электронных устройств»')
    {
        $contract_data[1] = '3 года 10 месяцев';
        if ($contract_data[0] == 'за счет средств республиканского бюджета')
        {
            $contract_data[2] = '13596,95 (тринадцать тысяч пятьсот девяносто шесть рублей 95 копеек)';
        }
    } 

    elseif ($arr[0] == '«Правоведение»')
    {
        $contract_data[2] = '2725,00 (две тысячи семьсот двадцать  пять рублей 00 копеек)';
        if ($arr[1] == 'второй')
        {
            $contract_data[1] = '1 год 10 месяцев';
        }
        else $contract_data[1] = '2 года 10 месяцев';
        if ($contract_data[0] == 'за счет средств республиканского бюджета')
        {
            $contract_data[2] = '12414,61 (двенадцать тысяч четыреста четырнадцать рублей 61 копейка)';
        }
    }

    return $contract_data;
}

function mother_or_father($key)
{
    $txt = ['fls', 'adress', 'passport'];
    $pasport_data = [$_POST['parent_document'], $_POST['parent_passport_serial'], $_POST['parent_passport_number'], $_POST['parent_passport_when'], $_POST['parent_passport_who'], $_POST['parent_passport_identifical']];
    $parent_pasport_data = get_passport_data($pasport_data);
    if ($key == 'mother')
    {
        $adress_data = [$_POST['mother_address-index'], $_POST['mother_address-region'], first_upper($_POST['mother_address-area']), first_upper($_POST['mother_address-city']), $_POST['mother_address-citytype'], first_upper($_POST['mother_address-street']), $_POST['mother_address-house'], $_POST['mother_address-appartment']];
        $txt[0] = parent_upper($_POST['mother_flsname']);
    }
    else 
    {
        $adress_data = [$_POST['father_address-index'], $_POST['father_address-region'], first_upper($_POST['father_address-area']), first_upper($_POST['father_address-city']), $_POST['father_address-citytype'], first_upper($_POST['father_address-street']), $_POST['father_address-house'], $_POST['father_address-appartment']];
        $txt[0] = parent_upper($_POST['father_flsname']);
    }
    $parent_adress_data = get_adress($adress_data);
    $txt[1] = $parent_adress_data;
    $txt[2] = $parent_pasport_data;

    return $txt;
}

function first_upper($str)
{
    $array = [["а","А"], ["б","Б"], ["в","В"], ["г","Г"], ["д","Д"], ["е","Е"], ["ж","Ж"], ["з","З"], ["и","И"], ["к","К"], ["л","Л"], ["м","М"], ["н","Н"], ["о","О"], ["п","П"],
    ["р","Р"], ["с","С"], ["т","Т"], ["у","У"], ["ф","Ф"], ["х","Х"], ["ц","Ц"], ["ч","Ч"], ["ш","Ш"], ["щ","Щ"], ["э","Э"], ["ю","Ю"], ["я","Я"]];

    if ($str != "")
    {
        $new_str = str_split($str, 2);
        for($i = 0; $i<count($array); $i++)
        {
            if ($new_str[0] == $array[$i][0])
            {
                $new_str[0] = $array[$i][1];
                break;
            }
        }

        $finish_str = implode($new_str);
    }
    else $finish_str = $str;

    return $finish_str;
}

function parent_upper($str)
{
    $new_str = explode(" ", $str);
    $new_string = '';
    for ($i = 0; $i< count($new_str); $i++)
    {
        if ($i != count($new_str) - 1)
        {
            $new_string .= first_upper($new_str[$i]) . " ";
        }
        else $new_string .= first_upper($new_str[$i]);
    }
    return $new_string;
}

function zaayvlenie($tcpdf, $data_from_page, $budjet_platno)
{
    require_once 'TCPDF-main/tcpdf.php';

    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);

    $tcpdf->AddPage();

    $tcpdf->setCellPaddings(1, 0, 1, 0);
    $tcpdf->setCellMargins(1, 0, 1, 0);

    $txt = "Допустить к участию в конкурсе для получения среднего специального образования\nДиректор _________ В.С.Басов\n___ ____________ 2023г.";
    $tcpdf->MultiCell(70, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = " ";
    $tcpdf->MultiCell(8, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = 'Зачислить на ' . $data_from_page[0] . ' курс на специальность ' . $data_from_page[1]. ' ' . $data_from_page[2]."\nПриказ ____ августа 2023г. № ____\nДиректор ___________ В.С.Басов";
    $tcpdf->MultiCell(95, 0, $txt, 0, 'L', 0, 1, '', '', true);

    $txt = '  ';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);

    $txt = '  Руководителю учреждения образования «Бресткий государственный';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = 'технический унииверситет» в лице директора филиала учреждения образования';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = '«Бресткий государственный технический унииверситет» Политехнический';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = 'колледж Басова Виктора Степановича';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);

    $txt = 'Фамилия';
    $tcpdf->MultiCell(50, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_lastname'];
    $tcpdf->MultiCell(50, 5, first_upper($txt), 0, 'L', 0, 1, '', '', true);

    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = 'Имя';
    $tcpdf->MultiCell(50, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_firstname'];
    $tcpdf->MultiCell(50, 5, first_upper($txt), 0, 'L', 0, 1, '', '', true);

    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = 'Отчество';
    $tcpdf->MultiCell(50, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_surname'];
    $tcpdf->MultiCell(50, 5, first_upper($txt), 0, 'L', 0, 1, '', '', true);
    
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = '';
    $adress_data = [$_POST['student_address-index'], $_POST['student_address-region'], first_upper($_POST['student_address-area']), first_upper($_POST['student_address-city']), $_POST['student_address-citytype'], first_upper($_POST['student_address-street']), $_POST['student_address-house'], $_POST['student_address-appartment'], $_POST['student_address-homephone'], $_POST['student_address-mobilephone']];
    $txt = get_adress($adress_data);
    $tcpdf->MultiCell(0, 0, 'который(ая) проживает по адресу '. $txt, 0, 'L', 0, 1, '', '', true);

    $txt = $_POST['student_graduate'];
    $tcpdf->MultiCell(0, 10, 'и закончил(ла) '.$txt, 0, 'L', 0, 1, '', '', true);

    $tcpdf->setFont('timeromanb', '', 13);
    $html = '<span style="text-align: center;">ЗАЯВЛЕНИЕ</span>';
    $tcpdf->writeHTML($html, true, false, true, false, '');

    $tcpdf->setFont('timesnewromancyr', '', 13);
    $txt = '    Прошу допустить меня к участию в конкурсе для получения среднего специального образования по специальности ' . $_GET['number'] . $_GET['name'] . ' ' . $data_from_page[4] . ' ' . $budjet_platno . "\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = '       О себе сообщаю следующие сведения:';
    $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);
    $txt = 'Число, месяц, год рождения';
    $tcpdf->MultiCell(90, 0, $txt, 0, 'L', 0, 0, '', '', true);

    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_birthday'];
    $tcpdf->MultiCell(110, 5, $txt, 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = $_POST['student_profession'];
    $tcpdf->MultiCell(0, 0, 'Место работы, занимаемая должность (профессия) '.$txt, 0, 'L', 0, 1, '', '', true);
    $txt = $_POST['student_seniority'];
    $tcpdf->MultiCell(0, 0, 'Трудовой стаж по профилю избранной специальности '.$txt, 0, 'L', 0, 1, '', '', true);
    $txt = 'Нуждаюсь в общежитии';
    $tcpdf->MultiCell(90, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_dormitory'];
    $tcpdf->MultiCell(110, 5, $txt, 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = 'Изучал(ла) иностранный язык';
    $tcpdf->MultiCell(90, 10, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['student_froeignlan'];
    $tcpdf->MultiCell(110, 10, $txt, 0, 'L', 0, 1, '', '', true);

    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $txt = 'Родители:';
    $tcpdf->MultiCell(0, 5, $txt, 0, 'L', 0, 1, '', '', true);

    $txt = 'Отец';
    $tcpdf->MultiCell(50, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['father_flsname'];
    $tcpdf->MultiCell(150, 5, parent_upper($txt), 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $adress_data = [$_POST['father_address-index'], $_POST['father_address-region'], first_upper($_POST['father_address-area']), first_upper($_POST['father_address-city']), $_POST['father_address-citytype'], first_upper($_POST['father_address-street']), $_POST['father_address-house'], $_POST['father_address-appartment'], $_POST['father_address-homephone'], $_POST['father_address-mobilephone']];
    $txt = get_adress($adress_data);
    $tcpdf->MultiCell(0, 12, 'проживает по адресу '.$txt, 0, 'L', 0, 1, '', '', true);

    $txt = 'Мать';
    $tcpdf->MultiCell(50, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['mother_flsname'];
    $tcpdf->MultiCell(150, 5, parent_upper($txt), 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $adress_data = [$_POST['mother_address-index'], $_POST['mother_address-region'], first_upper($_POST['mother_address-area']), first_upper($_POST['mother_address-city']), $_POST['mother_address-citytype'], first_upper($_POST['mother_address-street']), $_POST['mother_address-house'], $_POST['mother_address-appartment'], $_POST['mother_address-homephone'], $_POST['mother_address-mobilephone']];
    $txt = get_adress($adress_data);
    $tcpdf->MultiCell(0, 12, 'проживает по адресу '.$txt, 0, 'L', 0, 1, '', '', true);

    $txt = 'Имею право на льготы';
    $tcpdf->MultiCell(90, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 13, '', false);
    $txt = $_POST['privileges'];
    $tcpdf->MultiCell(110, 5, $txt, 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 13, '', false);
    $pasport_data = [$_POST['child_document'], $_POST['child_passport_serial'], $_POST['child_passport_number'], $_POST['child_passport_when'], $_POST['child_passport_who'], $_POST['child_passport_identifical']];
    $txt = get_passport_data($pasport_data);
    $tcpdf->MultiCell(0, 12, 'Данные документа, удостоверяющего личность '.$txt, 0, 'L', 0, 1, '', '', true);

    $txt = 'С правилами приема и порядком подачи апеляции ознакомлен(на).';
    $tcpdf->MultiCell(0, 10, $txt, 0, 'L', 0, 1, '', '', true);
    $txt = '_______________________________';
    $tcpdf->MultiCell(75, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = '_______________________________';
    $tcpdf->MultiCell(95, 5, $txt, 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
    $txt = '(дата заполнения заявления)';
    $tcpdf->MultiCell(75, 0, $txt, 0, 'C', 0, 0, '', '', true);
    $txt = '(подпись)';
    $tcpdf->MultiCell(95, 5, $txt, 0, 'C', 0, 1, '', '', true);

    $data = implode(';', $data_from_page);
    $data .= ';' . $_POST['student_lastname'] . ';' . $_POST['student_firstname'] . ';' .$_POST['student_address-region'] . ';' .$_POST['student_address-area'] . ';' .$_POST['student_address-city'] . ';' . $_POST['student_address-street'] . ';' . $_POST['student_address-house'] . ';' . $_POST['student_address-appartment'] . ';' . $_POST['student_address-mobilephone'] . ';' . $_POST['student_graduate'] . "\n";
    file_put_contents('data.txt', $data, FILE_APPEND | LOCK_EX);
}

function dogovor_budjet($tcpdf, $data_from_page, $payment)
{
    $tcpdf->SetFont('timeromanb', '', 10, '', false);

        $tcpdf->setCellPaddings(1, 0, 1, 0);
        $tcpdf->setCellMargins(1, 0, 1, 0);

        $txt = "ДОГОВОР _________";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'C', 0, 1, '', '', true);
        $txt = "о подготовке специалиста (рабочего) со средним специальным образованием\nза счет средств республиканского (местного) бюджета";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'C', 0, 1, '', '', true);

        $tcpdf->SetFont('timesnewromancyr', '', 10, '', false);
        $txt = '___ _________ 2023 г.';
        $tcpdf->MultiCell(145, 5, $txt, 0, 'L', 0, 0, '', '', true);
        $txt = 'г. Брест';
        $tcpdf->MultiCell(15, 5, $txt, 0, 'L', 0, 1, '', '', true);

        $txt = "          Учреждение образования «Брестский государственный технический университет» в лице директора филиала учреждения образования «Брестский государственный технический университет» Политехнический колледж Басова Виктора Степановича, действующего на основании доверенности от 26.06.2023 № 17/2262, именуемое в дальнейшем Учреждение образования, с одной стороны, гражданин, иностранный гражданин (иностранный гражданин, лицо без гражданства, временно пребывающее или временно проживающее в Республике Беларусь) " . 
        first_upper($_POST['student_lastname']) . ' ' . first_upper($_POST['student_firstname']) . ' ' . first_upper($_POST['student_surname']) . ' ' . "именуемый в дальнейшем Обучающийся, с другой стороны, заключили настоящий договор о нижеследующем:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $data_for_create_contract = [$data_from_page[2], $data_from_page[0], $payment];
        $data = data_dogovor($data_for_create_contract);

        $txt = "          1. Предмет договора – подготовка специалиста (рабочего) со средним специальным образованием по специальности " .
        $data_from_page[1] . $data_from_page[2] . ' с присвоением квалификации ' . $data_from_page[4] . ' ' . "за счет средств республиканского (местного) бюджета.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "      Обучающийся зачисляется в Учреждение образования для освоения содержания образовательной программы среднего специального образования обеспечивающей получение квалификации со средним специальным образованием на основании протокола приемной комиссии от __.08.2023 № __.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "            2. Срок получения образования составляет " . $data[1] . ".\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "       3. Стоимость обучения определяется Учреждением образования в ценах текущего года и на момент заключения настоящего договора составляет " . $data[2] . ".\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "            4. Порядок изменения стоимости обучения.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          Стоимость обучения, указанная в пункте 3 настоящего договора, является предварительной и подлежит пересмотру на основании фактических расходов в случае, если у выпускника возникает обязанность возместить в республиканский (местный) бюджет средства, затраченные государством на его подготовку.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          Ликвидация академической задолженности Обучающимся, проведение повторных учебных занятий вне учебной группы при непосещении Обучающимся лабораторных и практических учебных занятий без уважительных причин в соответствии с их расписанием осуществляются за дополнительную оплату в соответствии с законодательством.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          Академической задолженностью признается не сдача в установленный срок (пропуск без уважительных причин) зачета, экзамена, курсового проекта, контрольной, лабораторной, практической работы, практики предусмотренных учебными планами, а также отметка ниже 3 баллов по учебному предмету, практике за семестр и указанным видам текущей аттестации.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "          5. Права и обязанности сторон:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          5.1. Учреждение образования имеет право:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          самостоятельно определять формы, методы и способы осуществления образовательного процесса;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "         осуществлять реализацию содержания образовательной программы среднего специального образования посредством сетевой формы взаимодействия на основании договора о сетевой форме взаимодействия;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "         досрочно прекращать образовательные отношения на основаниях, установленных в статье 68 Кодекса Республики Беларусь об образовании;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "         применять меры дисциплинарного взыскания при наличии оснований, предусмотренных в статье 118 Кодекса Республики Беларусь об образовании.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          5.2. Учреждение образования обязуется:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          зачислить Обучающегося для получения образования приказом руководителя Учреждения образования и обеспечить его подготовку по специальности, указанной в пункте 1 настоящего договора, на русском языке;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "   организовать материально-техническое обеспечение образовательного процесса в соответствии с установленными санитарно-эпидемиологическими требованиями;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          предоставить обучающемуся по его заявлению отпуск в порядке, определенном законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "      выдать Обучающемуся, освоившему содержание образовательной программы среднего специального образования, соответствующий документ об образовании;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "     выдать Обучающемуся в случае досрочного прекращения образовательных отношений справку об обучении;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          распределить, перераспределить Обучающегося в соответствии с законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          5.3. Обучающийся имеет право:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "       получить среднее специальное образование по специальности в соответствии с пунктом 1 настоящего договора;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "       требовать от Учреждения образования оказания квалифицированных и качественных услуг согласно настоящему договору.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          5.4. Обучающийся обязуется:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "        добросовестно и ответственно относиться к освоению содержания образовательной программы среднего специального образования, программ воспитания;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);  
        $txt = "      выполнять требования учредительных документов, правил внутреннего распорядка для обучающихся, иных локальных правовых актов Учреждения образования;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          бережно относиться к имуществу Учреждения образования;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "    по окончании обучения в Учреждении образования отработать срок обязательной работы по распределению, установленный законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "      в случае неотработки срока обязательной работы по распределению возместить в республиканский (местный) бюджет средства, затраченные государством на его подготовку, в соответствии с законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "     для прохождения учебной практики приобрести специальную одежду и специальную обувь в соответствии с нормативными требованиями;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "         перед выходом на производственную практику  приобрести и предоставить копию страхового полиса о добровольном страховании от несчастных случаев и заболеваний.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "          6. Ответственность сторон:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "        6.1. За неисполнение или ненадлежащее исполнение своих обязательств по настоящему договору стороны несут ответственность в соответствии с законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "      6.2. Обучающийся несет ответственность перед Учреждением образования за причинение вреда имуществу Учреждения образования в соответствии с законодательством.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "          7. Дополнительные условия договора (по договоренности сторон):\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "         7.1. в случае употребления спиртных напитков, употребления наркотических или токсических средств и (или) нахождения Обучающегося в состоянии алкогольного или токсического опьянения в Учреждении образования, на его территории настоящий договор расторгается, и Обучающийся подлежит отчислению из Учреждения образования.\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "          8. Заключительные положения:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "      8.1. настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, по одному для каждой из сторон;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "     8.2. договор вступает в силу со дня его подписания и действует до исполнения сторонами своих обязательств;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          8.3. договор изменяется и расторгается в соответствии с законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          8.4. вносимые изменения (дополнения) оформляются дополнительными соглашениями;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "     8.5. все споры и разногласия по настоящему договору стороны решают путем переговоров, а при недостижении согласия – в порядке, установленном законодательством;\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "          9. Адреса, реквизиты и подписи сторон:\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $txt = "          ";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $txt = "Учреждение образования\nНаименование: учреждение образования\n«Брестский государственный\nтехнический университет»\nМестонахождение:\nул. Московская, 267, г. Брест, 224017\nфилиал учреждения образования «Брестский\nгосударственный технический университет»\nПолитехнический колледж\nМестонахождение:\nул. К. Маркса, 49, г. Брест, 224030\nТел/факс:8(0162) 51 33 54\nБанковские реквизиты:\nр/с BY14 AKBB 3604 9000 0285 7100 0000\nОАО «АСБ Беларусбанк», БИК: АКВВBY2X\nУНН 201025287,ОКПО 020716131002\nДиректор: Басов Виктор Степанович";
        $tcpdf->MultiCell(75, 80, $txt, 0, 'L', 0, 0, '', '', true, 0, false, true, 80);

        $txt = " ";
        $tcpdf->MultiCell(23, 8, $txt, 0, 'L', 0, 0, '', '', true, 0, false, true, 80);
        
        $adress_data = [$_POST['student_address-index'], $_POST['student_address-region'], first_upper($_POST['student_address-area']), first_upper($_POST['student_address-city']), $_POST['student_address-citytype'], first_upper($_POST['student_address-street']), $_POST['student_address-house'], $_POST['student_address-appartment'], $_POST['student_address-homephone'], $_POST['student_address-mobilephone']];
        $adress = get_adress($adress_data);
        $pasport_data = [$_POST['child_document'], $_POST['child_passport_serial'], $_POST['child_passport_number'], $_POST['child_passport_when'], $_POST['child_passport_who'], $_POST['child_passport_identifical']];
        $pasport = get_passport_data($pasport_data);
        $txt = "Обучающийся\n" . first_upper($_POST['student_lastname']) . ' ' . first_upper($_POST['student_firstname']) . ' ' . first_upper($_POST['student_surname']) . "\nМесто жительства: " . $adress . "\nДокумент, удостоверяющий личность\n(вид документа, серия (при наличии), номер,\nдата выдачи, наименование или код\nгосударственного органа, его выдавшего,\nидентификационный номер (при наличии)\n" . $pasport . "\n\n\n";
        $tcpdf->MultiCell(75, 80, $txt, 0, 'L', 0, 1, '', '', true, 0, false, true, 80);

        $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
        $txt = "_______________________________________\n                         (подпись)";
        $tcpdf->MultiCell(75, 0, $txt, 0, 'L', 0, 0, '', '', true);
        $txt = " ";
        $tcpdf->MultiCell(23, 0, $txt, 0, 'L', 0, 0, '', '', true);
        $txt = "_______________________________________\n                         (подпись)";
        $tcpdf->MultiCell(75, 0, $txt, 0, 'L', 0, 1, '', '', true);
        $txt = " ";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

        $tcpdf->SetFont('timesnewromancyr', '', 10, '', false);
        $mum_or_dad = mother_or_father($_POST['parent_document_mum_or_dad']);
        $txt = "          С заключением настоящего договора несовершеннолетним(ей) " . $_POST['student_lastname'] . ' ' . $_POST['student_firstname'] . ' ' . $_POST['student_surname'] . " согласен(на) " . $mum_or_dad[0] . ', ' .  $mum_or_dad[1] . ', ' .  $mum_or_dad[2] . ".\n";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
        $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
        $txt = "\n_______________________________________\n                         (подпись)";
        $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);
}

function dogovor_platno($tcpdf, $data_from_page, $payment)
{
    $tcpdf->SetFont('timeromanb', '', 8, '', false);

    $tcpdf->setCellPaddings(1, 0, 1, 0);
    $tcpdf->setCellMargins(1, 0, 1, 0);

    $txt = "ДОГОВОР _________";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'C', 0, 1, '', '', true);
    $txt = "о подготовке специалиста (рабочего) со средним специальным\nобразованием на платной основе";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'C', 0, 1, '', '', true);

    $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
    $txt = '___ _________ 2023 г.';
    $tcpdf->MultiCell(145, 5, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = 'г. Брест';
    $tcpdf->MultiCell(15, 5, $txt, 0, 'L', 0, 1, '', '', true);

    if ($_POST['parent_document_mum_or_dad'] == 'mother')
    {
        $m_or_d = parent_upper($_POST['mother_flsname']);
    }
    else 
    {
        $m_or_d = parent_upper($_POST['father_flsname']);
    }
    
    $txt = "          Учреждение образования «Брестский государственный технический университет» в лице директора филиала учреждения образования «Брестский государственный технический университет» Политехнический колледж Басова Виктора Степановича, действующего на основании доверенности от 26.06.2023 № 17/2262, именуемое в дальнейшем Учреждение образования, с одной стороны, гражданин, иностранный гражданин (иностранный гражданин, лицо без гражданства, временно пребывающее или временно проживающее в Республике Беларусь) " . 
    first_upper($_POST['student_lastname']) . ' ' . first_upper($_POST['student_firstname']) . ' ' . first_upper($_POST['student_surname']) . ' ' . "именуемый в дальнейшем Обучающийся, с другой стороны, и " . $m_or_d . " в дальнейшем именуемый Плательщик, с третьей стороны, заключили настоящий договор о нижеследующем:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $data_for_create_contract = [$data_from_page[2], $data_from_page[0], $payment];
    $data = data_dogovor($data_for_create_contract);

    $txt = "          1. Предмет договора – подготовка специалиста (рабочего) со средним специальным образованием по специальности " .
    $data_from_page[1] . $data_from_page[2] . ' с присвоением квалификации ' . $data_from_page[3] . ' ' . $data_from_page[4] . ' ' . "на платной основе за счет средств Плательщика.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "       Обучающийся зачисляется в Учреждение образования для освоения содержания образовательной программы среднего специального образования обеспечивающей получение квалификации со средним специальным образованием на основании протокола приемной комиссии от __.08.2023 № __.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "            2. Срок получения образования составляет " . $data[1] . ".\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "        3. Стоимость обучения определяется Учреждением образования в ценах текущего года и на момент заключения настоящего договора составляет " . $data[2] . ".\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "            4. Порядок изменения стоимости обучения.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         Стоимость обучения, предусмотренная настоящим договором, может изменяться в связи с изменением условий формирования стоимости платного обучения, условий оплаты труда, ростом коммунальных платежей и иных расходов, необходимых для обеспечения процесса обучения с учетом инфляции.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          Изменение стоимости обучения утверждается приказом руководителя Учреждения образования, который в течение 7 календарных дней доводится до сведения Обучающегося и Плательщика. В случае изменения стоимости обучения Плательщик производит доплату разницы в стоимости не позднее 30 дней со дня доведения до сведения Обучающегося и Плательщика соответствующего приказа руководителя Учреждения образования.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "            5. Порядок расчетов за обучение:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        5.1. оплата за обучение на основании настоящего договора осуществляется Плательщиком на текущий (расчетный) счет BY55 АКВВ 3632 9000 0214 8100 0000, ОАО «АСБ Беларусбанк», БИК: АКВВBY2X, УНП 201025287 или в кассу бухгалтерии Учреждения образования;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          5.2. за первый год обучения оплата производится после издания приказа о зачислении Обучающегося в Учреждение образования в два этапа в следующие сроки:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    if ($data[2] == '2385,00 (две тысячи триста восемьдесят пять рублей 00 копеек)')
    {
        $payment_steps = ['1193,00  (одна тысяча сто девяносто три рубля 00 копеек)', '1192,00 (одна тысяча сто девяносто два рубля 00 копеек)'];
    }
    else $payment_steps = ['1363,00  (одна тысяча триста шестьдесят три рубля 00 копеек)', '1362,00 (одна тысяча триста шестьдесят два рубля 00 копеек)'];
    
    $tcpdf->SetFont('timesnewromancyrkursywa', '', 8, '', false);
    $txt = "          I этап - до 31 августа 2023 г., в размере " . $payment_steps[0] . ";\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          II этап -  до 15 февраля 2024 г., в размере " . $payment_steps[1] . ";\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
    $txt = "          Сроки доплаты разницы в стоимости обучения определяются приказом директора филиала.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         5.3. за последующие годы обучения оплата производится в порядке, определенном подпунктом 5.1 настоящего пункта, в следующие сроки: 1-й этап – до 15 сентября; 2-й этап – до 15 февраля;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         5.4. при восстановлении (переводе) Обучающегося оплата производится в полном размере за семестр, в котором Обучающийся зачисляется в Учреждение образования в сроки, указанные в пункте 5.3 настоящего договора;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          5.5. при наличии задолженности оплаты за обучения Обучающийся может быть не допущен к очередной экзаменационной сессии, государственному экзамену и защите дипломного проекта. В случае просрочки платежей более 30 календарных дней Обучающийся по решению директора может быть отчислен без предварительного уведомления.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        5.6. При отчислении Обучающегося сумма оплаты за обучение считается путем деления общей суммы за обучение за данный учебный год на продолжительность обучения (в днях) в данном учебном году и умножения на количество календарных дней, рассчитанных с 1 сентября до даты отчисления, указанной в приказе на отчисление Обучающегося. Дата отчисления не включается в расчет задолженности.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          Оплаченные (перечисленные) суммы по платному обучению к зачету принимаются в следующем порядке:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          – сумма задолженности за обучение за предыдущий этап (при наличии таковой);\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          – сумма начисленной пени за предыдущий этап (при наличии таковой);\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          – сумма оплаты за обучение за следующий этап.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "       5.7. Если Обучающийся отчисляется из Учреждения образования по неуважительным причинам, денежные средства не возвращаются. В случае отчисления по уважительным причинам производится возврат денежных средств, не затраченных на обучение. В бесспорном порядке уважительным признается отчисление учащегося по состоянию здоровья на основании справки ВКК. Уважительность причин при отчислении по иным основаниям определяется администрацией Учреждения образования при предоставлении учащимся соответствующих документов.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          5.8. Обязательства по оплате за обучение считаются исполненными с момента зачисления денежных средств на расчетный счет филиала.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "          6. Ликвидация академической задолженности Обучающимся, проведение повторных учебных занятий вне учебной группы при непосещении Обучающимся лабораторных и практических учебных занятий без уважительных причин в соответствии с их расписанием осуществляются за дополнительную оплату в соответствии с законодательством. Академической задолженностью признается несдача в установленный срок (пропуск без уважительных причин) зачета, экзамена, курсового проекта, контрольной, лабораторной, практической работы предусмотренных учебными планами, а также отметка ниже 3 баллов по учебному предмету, практике за семестр и указанным видам текущей аттестации.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "            7. Права и обязанности сторон:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "            7.1. Учреждение образования имеет право:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "            самостоятельно определять формы, методы и способы осуществления образовательного процесса;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        осуществлять реализацию содержания образовательной программы среднего специального образования посредством сетевой формы взаимодействия на основании договора о сетевой форме взаимодействия;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         досрочно прекращать образовательные отношения на основаниях, установленных в статье 68 Кодекса Республики Беларусь об образовании;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          применять меры дисциплинарного взыскания при наличии оснований, предусмотренных в статье 118 Кодекса Республики Беларусь об образовании;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          7.2. Учреждение образования обязуется:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        зачислить Обучающегося для получения образования приказом руководителя Учреждения образования и обеспечить его подготовку по специальности, указанной в пункте 1 настоящего договора, на русском языке;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "       организовать материально-техническое обеспечение образовательного процесса в соответствии с установленными санитарно-эпидемиологическими требованиями;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "           предоставить обучающемуся по его заявлению отпуск в порядке, определенном законодательством;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "     выдать Обучающемуся, освоившему содержание образовательной программы среднего специального образования, соответствующий документ об образовании;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          выдать Обучающемуся в случае досрочного прекращения образовательных отношений справку об обучении;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         возвратить Плательщику денежные средства, внесенные за обучение, с учетом фактического срока обучения, за который вносилась плата, в случае досрочного прекращения образовательных отношений;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          7.3. Обучающийся имеет право:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          получить среднее специальное образование по специальности в соответствии с пунктом 1 настоящего договора;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          требовать от Учреждения образования оказания квалифицированных и качественных услуг согласно настоящему договору;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          7.4. обязанности Обучающегося:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "      добросовестно и ответственно относиться к освоению содержания образовательной программы среднего специального образования, программ воспитания;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        выполнять требования учредительных документов, правил внутреннего распорядка для обучающихся, иных локальных правовых актов Учреждения образования;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          бережно относиться к имуществу Учреждения образования;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        для прохождения учебной практики приобрести специальную одежду и специальную обувь в соответствии с нормативными требованиями;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          перед выходом на производственную практику приобрести и предоставить копию страхового полиса о добровольном страховании от несчастных случаев и заболеваний;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          осуществлять оплату стоимости обучения в сроки, установленные настоящим договором;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          7.5. Плательщик имеет право получать от Учреждения образования сведения о результатах обучения Обучающегося;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          7.6. Плательщик обязуется осуществлять оплату за обучение в сроки, установленные настоящим договором.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "          8. Ответственность сторон:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         8.1. за неисполнение или ненадлежащее исполнение своих обязательств по настоящему договору стороны несут ответственность в соответствии с законодательством;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "        8.2. при нарушении сроков оплаты, предусмотренных пунктами 4 и 5 настоящего договора, Плательщик выплачивает пеню в размере 0,1 % от суммы просроченных платежей за каждый день просрочки. Пеня начисляется со следующего дня после истечения срока оплаты;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         8.3. в случае просрочки платежей свыше 1 месяца Обучающийся по решению руководителя Учреждения образования может быть отчислен из Учреждения образования;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "      8.4. Обучающийся несет ответственность перед Учреждением образования за причинение вреда имуществу Учреждения образования в соответствии с законодательством.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "         8.5. Обучающийся (Плательщик) несет ответственность за достоверность представленных банку для проведения оплаты сведений и сохранение своих экземпляров квитанций, договоров в течение всего срока обучения.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "          9. Дополнительные условия договора (по договоренности сторон):\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "      9.1. в случае употребления спиртных напитков, употребления наркотических или токсических средств и (или) нахождения Учащегося в состоянии алкогольного или токсического опьянения в Учреждении образования, на его территории настоящий договор с Учащимся расторгается, и Учащийся подлежит отчислению из Учреждения образования.\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "          10. Заключительные положения:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          10.1. настоящий договор составлен в трех экземплярах, имеющих одинаковую юридическую силу, по одному для каждой из сторон;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          10.2. договор вступает в силу со дня его подписания сторонами и действует до исполнения сторонами своих обязательств;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          10.3. договор изменяется и расторгается в соответствии с законодательством;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "          10.4. вносимые изменения (дополнения) оформляются дополнительными соглашениями;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $txt = "      10.5. все споры и разногласия по настоящему договору стороны решают путем переговоров, а при недостижении согласия  – в порядке, установленном законодательством;\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "          11. Адреса, реквизиты и подписи сторон:\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);

    $txt = "Учреждение образования\nНаименование: учреждение образования\n«Брестский государственный\nтехнический университет»\nМестонахождение:\nул. Московская, 267, г. Брест, 224017\nфилиал учреждения образования «Брестский\nгосударственный технический университет»\nПолитехнический колледж\nМестонахождение:\nул. К. Маркса, 49, г. Брест, 224030\nТел/факс:8(0162) 51 33 54\nБанковские реквизиты:\nр/с BY14 AKBB 3604 9000 0285 7100 0000\nОАО «АСБ Беларусбанк», БИК: АКВВBY2X\nУНН 201025287,ОКПО 020716131002\nДиректор: Басов Виктор Степанович";
    $tcpdf->MultiCell(60, 60, $txt, 0, 'L', 0, 0, '', '', true, 0, false, true, 60);

    $adress_data = [$_POST['student_address-index'], $_POST['student_address-region'], first_upper($_POST['student_address-area']), first_upper($_POST['student_address-city']), $_POST['student_address-citytype'], first_upper($_POST['student_address-street']), $_POST['student_address-house'], $_POST['student_address-appartment'], $_POST['student_address-homephone'], $_POST['student_address-mobilephone']];
    $adress = get_adress($adress_data);
    $pasport_data = [$_POST['child_document'], $_POST['child_passport_serial'], $_POST['child_passport_number'], $_POST['child_passport_when'], $_POST['child_passport_who'], $_POST['child_passport_identifical']];
    $pasport = get_passport_data($pasport_data);
    $txt = "Обучающийся\n" . first_upper($_POST['student_lastname']) . ' ' . first_upper($_POST['student_firstname']) . ' ' . first_upper($_POST['student_surname']) . "\nМесто жительства: " . $adress . "\nДокумент, удостоверяющий личность (вид документа, серия (при наличии), номер, дата выдачи, наименование или код государственного органа, его выдавшего,идентификационный номер (при наличии)\n" . $pasport . "\n\n\n";
    $tcpdf->MultiCell(55, 60, $txt, 0, 'L', 0, 0, '', '', true, 0, false, true, 60);

    $mum_or_dad = mother_or_father($_POST['parent_document_mum_or_dad']);

    $txt = "Плательщик\n" . $mum_or_dad[0] . "\nМесто жительства: " . $mum_or_dad[1] . "\nДокумент, удостоверяющий личность (вид документа, серия (при наличии), номер, дата выдачи, наименование или код государственного органа, его выдавшего, идентификационный номер (при наличии)\n" . $mum_or_dad[2] . "\n\n\n";
    $tcpdf->MultiCell(60, 60, $txt, 0, 'L', 0, 1, '', '', true, 0, false, true, 60);

    $tcpdf->SetFont('timesnewromancyr', '', 6, '', false);
    $txt = "\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);
    $txt = "__________________________________\n                         (подпись)";
    $tcpdf->MultiCell(60, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = "__________________________________\n                         (подпись)";
    $tcpdf->MultiCell(58, 0, $txt, 0, 'L', 0, 0, '', '', true);
    $txt = "__________________________________\n                         (подпись)";
    $tcpdf->MultiCell(58, 0, $txt, 0, 'L', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 8, '', false);
        
    $txt = "          С заключением настоящего договора несовершеннолетним(ей) " . $_POST['student_lastname'] . ' ' . $_POST['student_firstname'] . ' ' . $_POST['student_surname'] . " согласен(на) " .  $mum_or_dad[0] . ', ' .  $mum_or_dad[1] . ', ' .  $mum_or_dad[2] . ".\n";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'J', 0, 1, '', '', true);
    $tcpdf->SetFont('timesnewromancyr', '', 6, '', false);
    $txt = "\n_______________________________________\n                         (подпись)";
    $tcpdf->MultiCell(0, 0, $txt, 0, 'L', 0, 1, '', '', true);
}