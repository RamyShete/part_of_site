<?php
$ tcpdf_addfont.php -i arial.ttf
?>