<?php

require_once __DIR__ . '/incs/data.php'; 
require_once __DIR__ . '/incs/functions.php';


if (!empty($_POST) ) {
    $fields = load($fields);
    if($errors = validate($fields)) {
        debug($errors);
    } else {
        require_once 'TCPDF-main/tcpdf.php';

        $tcpdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8');

        $tcpdf->SetPrintHeader(false);
        $tcpdf->setPrintFooter(false);
    
        $tcpdf->SetCreator('Создатель');
        $tcpdf->SetAuthor('Автор файла');
        $tcpdf->SetTitle('Название файла');
        $tcpdf->SetSubject('Тема');
        $tcpdf->SetKeywords('Ключевые слова');

        //Устанавливаем отступы от края для всех страниц (слева, сверху, справа, снизу)
        $tcpdf->SetMargins(25, 8, 5);

        $budjet_platno = ["за счет средств республиканского бюджета", "на платной основе"];

        $data_from_page = [$_GET['course'], $_GET['number'], $_GET['name'], $_GET['qualification'], $_GET['education']];

        if ($_POST['value_button'] == 'budjet')
        {
            zaayvlenie($tcpdf, $data_from_page, $budjet_platno[0]);
            $tcpdf->AddPage();
            $tcpdf->AddPage();
            dogovor_budjet($tcpdf, $data_from_page, $budjet_platno[0]);
            $tcpdf->AddPage();
            dogovor_budjet($tcpdf, $data_from_page, $budjet_platno[0]);
        }
        elseif ($_POST['value_button'] == 'platnoe')
        {
            zaayvlenie($tcpdf, $data_from_page, $budjet_platno[1]);
            $tcpdf->AddPage();
            $tcpdf->AddPage();
            dogovor_platno($tcpdf, $data_from_page, $budjet_platno[1]);
            $tcpdf->AddPage();
            dogovor_platno($tcpdf, $data_from_page, $budjet_platno[1]);
        }
        else
        {
            zaayvlenie($tcpdf, $data_from_page, $budjet_platno[0]);
            $tcpdf->AddPage();
            $tcpdf->AddPage();
            dogovor_budjet($tcpdf, $data_from_page, $budjet_platno[0]);
            $tcpdf->AddPage();
            dogovor_budjet($tcpdf, $data_from_page, $budjet_platno[0]);
            zaayvlenie($tcpdf, $data_from_page, $budjet_platno[1]);
            $tcpdf->AddPage();
            $tcpdf->AddPage();
            dogovor_platno($tcpdf, $data_from_page, $budjet_platno[1]);
            $tcpdf->AddPage();
            dogovor_platno($tcpdf, $data_from_page, $budjet_platno[1]);
        }

        $tcpdf->Output('Document.pdf', 'I');  
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Заполнение документов</title>
        <link rel="stylesheet" href="formP_style_beauty.css">
    </head>
    <body>
    <form method="post" class="needs-validation" novalidate>

        <div class="header">

            <div class="row">
                <div class="cell"><b>Специальность:</b></div><?=$_GET['name']?>
            </div>
            <div class="row">
                <div class="cell"><b>Курс:</b></div><?=$_GET['course']?>
            </div>
            <div class="row">
                <div class="cell"><b>Квалификация:</b></div><?=$_GET['qualification']?>
            </div>
            <div class="row">
                <div class="cell"><b>Форма обучения:</b></div>
                <?php if ($_GET['education'] == "в дневной форме получения образования" && $_GET['payment'] == "за счет средств республиканского бюджета"): ?> Дневная бюджет
                                    <?php elseif ($_GET['education'] == "в дневной форме получения образования" && $_GET['payment'] == "на платной основе"): ?> Дневная платно
                                    <?php elseif ($_GET['education'] == "в дневной форме получения образования" && $_GET['payment'] == "all"): ?> Дневная бюжет/платно
                                    <?php elseif ($_GET['education'] == "в заочной форме получения образования" && $_GET['payment'] == "за счет средств республиканского бюджета"): ?> Заочная бюджет
                                    <?php elseif ($_GET['education'] == "в заочной форме получения образования" && $_GET['payment'] == "на платной основе"): ?> Заочная платно
                                    <?php elseif ($_GET['education'] == "в заочной форме получения образования" && $_GET['payment'] == "all"): ?> Заочная бюджет/платно    
                                    <?php endif; ?>
            </div>
        </div>
        
        <div class="block" style="margin-top: 50px;">
            <b>Абитуриент</b>
            <div class="row">
                <div class="left_column">
                    <div class="form__field">
                        <label for="student_lastname">Фамилия</label><br>
                        <input type="text" name="student_lastname" placeholder="Иванов" required pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Фамилия" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="student_firstname">Имя</label><br>
                        <input type="text" name="student_firstname" placeholder="Иван" required pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Имя" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="student_surname">Отчество</label><br>
                        <input type="text" name="student_surname" placeholder="Иванович" pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Отчетсво" небходимо написать русскими буквами</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="student_birthday">Дата рождения</label><br>
                        <input type="text" name="student_birthday" placeholder="01.01.2000" required pattern="[0-3][0-9]\.[01][0-9]\.[12][90][0-9][0-9]" />
                        <span class="form__error">Поле "Дата рождения" небходимо написать в формате ДД.ММ.ГГГГ</span>
                    </div>
                    <div class="form__field">
                        <label for="student_address-mobilephone">Мобильный телефон</label><br>
                        <input type="text" name="student_address-mobilephone" placeholder="+375291234567" required pattern="[\+](375)\d{9}" />
                        <span class="form__error">Поле "Мобильный телефон" небходимо написать в формате +375291234567</span>
                    </div>
                    <div class="form__field">
                        <label for="student_address-homephone">Домашний телефон</label><br>
                        <input type="text" name="student_address-homephone" placeholder="80162123456" pattern="(80)\d{3,4}\d{6}" />
                        <span class="form__error">Поле "Домашний телефон" небходимо написать в формате 80162123456</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="block">
            <i>Адрес по месту прописки</i>
            <div class="row">
                <div class="left_column">
                    <div class="form__field">
                        <label for="student_address-index">Индекс</label><br>
                        <input type="text" name="student_address-index" placeholder="224017" required pattern="\d{6}" />
                        <span class="form__error">Поле "Индекс" небходимо написать в формате 224017</span>
                    </div>
                    <div class="form__field">
                        <label for="student_address-region">Область</label><br>
                        <select name="student_address-region" style="width: 492px;">
                            <option value="choose_region">Выберите область</option>
                            <option value="Брестская">Брестская</option>
                            <option value="Витебская">Витебская</option>
                            <option value="Гомельская">Гомельская</option>
                            <option value="Гродненская">Гродненская</option>
                            <option value="Минская">Минская</option>
                            <option value="Могилевская">Могилевская</option>
                        </select>
                    </div>
                    <div class="form__field">
                        <label for="student_address-area">Район (если требуется)</label><br>
                        <input type="text" name="student_address-area" placeholder="Брестский" pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Район" небходимо написать русскими буквами</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="student_address-citytype">Город</label><br>
                        <select id="student_address-citytype" name="student_address-citytype" style="width: 200px; margin-right:25px">
                            <option value="город">город</option>
                            <option value="городской поселок">городской поселок</option>
                            <option value="агрогородок">агрогородок</option>
                            <option value="деревня">деревня</option>
                        </select>
                        <input type="text" name="student_address-city" placeholder="Брест" style="width: 250px;" required pattern="[а-яА-Я]+"/>
                        <span class="form__error">Поле "Город" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="student_address-street">Улица</label><br>
                        <input type="text" name="student_address-street" placeholder="Советская" required pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Улица" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="student_address-house" style="margin-right: 235px;">Дом</label>
                        <label for="student_address-appartment">Квартира</label><br>
                        <input name="student_address-house" type="text" style="width: 200px; margin-right:60px" placeholder="100" autocomplete="off" 
                        required pattern="(\d{1,3}|\d{1,3}[а-яА-Я]{1}|\d{1,3}\/[0-9]|\d{1,3}\/[а-яА-Я]|\d{1,3}[а-яА-Я]\/[0-9]|\d{1,3}[0-9]\/[а-яА-Я])"/>
                        <span class="form__error">Поле "Дом" небходимо написать в форматах 1, 12, 123, 123А, 123/2, 123/2 А</span>
                        <input name="student_address-appartment" type="text" style="width: 200px;" placeholder="1" autocomplete="off" pattern="\d{1,3}"/>
                        <span class="form__error">Поле "Квартира" небходимо написать в форматах 1, 12, 123</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="block">
            <div class="form__field">
                <label for="student_graduate">Год окончания, наименование УО</label>
                <input name="student_graduate" type="text" placeholder="2023, ГУО &#171;СШ№27 г.Бреста&#187;" pattern="\d{4},\s.+$" style="width: 1045px;">
                <span class="form__error">Это поле небходимо написать в формате ГГГГ, наименования учреждения образования</span>
            </div>
            <div class="row">
                <div style="width: 345px; margin-right: 75px;">
                    <label for="student_froeignlan">Изучал(ла) иностранный язык</label>
                    <select id="student_froeignlan" name="student_froeignlan" style="width: 300px;">
                            <option value="английский">английский</option>
                            <option value="немецкий">немецкий</option>
                            <option value="французкий">французкий</option>
                            <option value="испанский">испанский</option>
                            <option value="китайский">китайский</option>
                    </select>
                </div>
                <div style="width: 250px; margin-right: 75px;">
                    <div>Нуждаюсь в общежитии</div>
                    <label>
                        <input type="radio" class="custom-radio" name="student_dormitory" checked value="да" style="width: 15px; margin-top: 12px;">
                        да
                    </label>
                    <label>
                        <input type="radio" class="custom-radio" name="student_dormitory" value="нет" style="width: 15px; margin-top: 12px;">
                        нет
                    </label>
                </div>
                <div style="width: 345px;">
                    <label for="privileges">Имею право на льготы</label>
                    <input name="privileges" type="text" placeholder="нет" style="width: 300px;">
                    <span class="form__error">Поле "Город" небходимо написать русскими буквами</span>
                </div>
            </div>
            <div class="form__field">
                <label for="student_profession">Место работы, занимаемая должность (профессия)</label>
                <input name="student_profession" type="text" style="width: 1045px;" placeholder="для студентов, поступающих на заочное отделение">
            </div>
            <div class="form__field">
                <label for="student_seniority">Трудовой стаж по профилю избранной специальности</label>
                <input name="student_seniority" type="text" style="width: 1045px;" placeholder="для студентов, поступающих на заочное отделение">
            </div>
        </div>

        <div class="block" style="margin-top: 50px;">
            <b>Документ абитуриента</b>
            <div class="row">
                <div style="margin-right: 75px;">
                    <div class="form__field">
                        <select id="child_document" name="child_document" style="width: 492px; margin-top: 25px;">
                            <option value="паспорт">паспорт</option>
                            <option value="вид на жительство">вид на жительство</option>
                            <option value="id card">id card</option>
                        </select>
                    </div>
                    <div class="form__field" style="width: 492px;">
                        <label for="child_passport_serial">Серия (при наличии)</label>
                        <input name="child_passport_serial" type="text" placeholder="КН" autocomplete="off" required pattern="[А-ЯA-Z]{2}" />
                        <span class="form__error">В поле "Серия" небходимо вписать две буквы номера документа (АВ, КН и т.д.)</span>
                    </div>
                    <div class="form__field" style="width: 492px;">
                        <label for="child_passport_number">Номер</label>
                        <input name="child_passport_number" type="text" placeholder="1234567" autocomplete="off" required pattern="\d{7}" />
                        <span class="form__error">В поле "Номер" небходимо вписать семь цифр номера документа (1234567)</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="child_passport_when">Когда выдан</label><br>
                        <input name="child_passport_when" type="text" placeholder="01.02.2020" autocomplete="off" required pattern="[0-3][0-9]\.[01][0-9]\.[12][90][0-9][0-9]" />
                        <span class="form__error">В поле "Когда выдан" небходимо вписать дату в формате ДД.ММ.ГГГГ</span>
                    </div>
                    <div class="form__field">
                    <label for="child_passport_who">Кем выдан</label><br>
                        <input name="child_passport_who" type="text" placeholder="Ленинским РОВД г.Бреста" required pattern="[а-яА-я\s\.]+" />
                        <span class="form__error">Поле "Кем выдан" небходимо заполнить русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="child_passport_identifical">Идентификационный номер</label>
                        <input name="child_passport_identifical" type="text" placeholder="1234567A001РВ1" autocomplete="off" required pattern="\d{7}[A-ZА-Я]{1}\d{3}[A-ZА-Я]{2}\d{1}" />
                        <span class="form__error">Поле "Идентификационный номер" небходимо написать в формате 1234567A001РВ1</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="block" style="margin-top: 50px;">
            <b>Мать</b>
            <div class="form__field">
                <label for="mother_flsname">Фамилия имя отчество матери</label>
                <input name="mother_flsname" type="text" placeholder="Иванова Ольга Сергеевна" pattern="[а-яА-Я]+\s[а-яА-Я]+\s[а-яА-Я]+" style="width: 1045px;">
                <span class="form__error">Это поле небходимо заполнить русскими буквами</span>
            </div>
        </div>

        <div class="block">
            <i>Адрес по месту прописки</i>
            <div class="row">
                <div class="left_column">
                    <div class="form__field">
                        <label for="mother_address-index">Индекс</label><br>
                        <input type="text" name="mother_address-index" placeholder="224017" required pattern="\d{6}" />
                        <span class="form__error">Поле "Индекс" небходимо написать в формате 224017</span>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-region">Область</label><br>
                        <select name="mother_address-region" style="width: 492px;">
                            <option value="choose_region">Выберите область</option>
                            <option value="Брестская">Брестская</option>
                            <option value="Витебская">Витебская</option>
                            <option value="Гомельская">Гомельская</option>
                            <option value="Гродненская">Гродненская</option>
                            <option value="Минская">Минская</option>
                            <option value="Могилевская">Могилевская</option>
                        </select>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-area">Район (если требуется)</label><br>
                        <input type="text" name="mother_address-area" placeholder="Брестский" pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Район" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-citytype">Город</label><br>
                        <select name="mother_address-citytype" style="width: 200px; margin-right:25px">
                            <option value="город">город</option>
                            <option value="городской поселок">городской поселок</option>
                            <option value="агрогородок">агрогородок</option>
                            <option value="деревня">деревня</option>
                        </select>
                        <input type="text" name="mother_address-city" placeholder="Брест" style="width: 250px;" required pattern="[а-яА-Я]+"/>
                        <span class="form__error">Поле "Город" небходимо написать русскими буквами</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="mother_address-street">Улица</label><br>
                        <input type="text" name="mother_address-street" placeholder="Советская" required pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Улица" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-house" style="margin-right: 235px;">Дом</label>
                        <label for="mother_address-appartment">Квартира</label><br>
                        <input name="mother_address-house" type="text" style="width: 200px; margin-right:60px" placeholder="100" autocomplete="off" required pattern="(\d{1,3}|\d{1,3}[а-яА-Я]{1}|\d{1,3}\/[0-9]|\d{1,3}\/[а-яА-Я])"/>
                        <span class="form__error">Поле "Дом" небходимо написать в форматах 1, 12, 123, 123А, 123/2, 123/2 А</span>
                        <input name="mother_address-appartment" type="text" style="width: 200px;" placeholder="1" autocomplete="off" pattern="\d{1,3}"/>
                        <span class="form__error">Поле "Квартира" небходимо написать в форматах 1, 12, 123</span>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-mobilephone">Мобильный телефон</label><br>
                        <input type="text" name="mother_address-mobilephone" placeholder="+375291234567" required pattern="[\+](375)\d{2}\d{7}" />
                        <span class="form__error">Поле "Мобильный телефон" небходимо написать в формате +375291234567</span>
                    </div>
                    <div class="form__field">
                        <label for="mother_address-homephone">Домашний телефон</label><br>
                        <input type="text" name="mother_address-homephone" placeholder="80162123456" pattern="(80)\d{3,4}\d{6}" />
                        <span class="form__error">Поле "Домашний телефон" небходимо написать в формате 80162123456</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="block" style="margin-top: 50px;">
            <b>Отец</b>
            <div class="form__field">
                <label for="father_flsname">Фамилия имя отчество отца</label>
                <input name="father_flsname" type="text" placeholder="Иванов Иван Петрович" pattern="[а-яА-Я]+\s[а-яА-Я]+\s[а-яА-Я]+" style="width: 1045px;">
                <span class="form__error">Это поле небходимо заполнить русскими буквами</span>
            </div>
        </div>

        <div class="block">
            <i>Адрес по месту прописки</i>
            <div class="row">
                <div class="left_column">
                    <div class="form__field">
                        <label for="father_address-index">Индекс</label><br>
                        <input type="text" name="father_address-index" placeholder="224017" required pattern="\d{6}" />
                        <span class="form__error">Поле "Индекс" небходимо написать в формате 224017</span>
                    </div>
                    <div class="form__field">
                        <label for="father_address-region">Область</label><br>
                        <select name="father_address-region" style="width: 492px;">
                            <option value="choose_region">Выберите область</option>
                            <option value="Брестская">Брестская</option>
                            <option value="Витебская">Витебская</option>
                            <option value="Гомельская">Гомельская</option>
                            <option value="Гродненская">Гродненская</option>
                            <option value="Минская">Минская</option>
                            <option value="Могилевская">Могилевская</option>
                        </select>
                    </div>
                    <div class="form__field">
                        <label for="father_address-area">Район (если требуется)</label><br>
                        <input type="text" name="father_address-area" placeholder="Брестский" pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Район" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="father_address-citytype">Город</label><br>
                        <select name="father_address-citytype" style="width: 200px; margin-right:25px">
                            <option value="город">город</option>
                            <option value="городской поселок">городской поселок</option>
                            <option value="агрогородок">агрогородок</option>
                            <option value="деревня">деревня</option>
                        </select>
                        <input type="text" name="father_address-city" placeholder="Брест" style="width: 250px;" required pattern="[а-яА-Я]+"/>
                        <span class="form__error">Поле "Город" небходимо написать русскими буквами</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="father_address-street">Улица</label><br>
                        <input type="text" name="father_address-street" placeholder="Советская" required pattern="[а-яА-Я]+" />
                        <span class="form__error">Поле "Улица" небходимо написать русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="father_address-house" style="margin-right: 235px;">Дом</label>
                        <label for="father_address-appartment">Квартира</label><br>
                        <input name="father_address-house" type="text" style="width: 200px; margin-right:60px" placeholder="100" autocomplete="off" required pattern="(\d{1,3}|\d{1,3}[а-яА-Я]{1}|\d{1,3}\/[0-9]|\d{1,3}\/[а-яА-Я])"/>
                        <span class="form__error">Поле "Дом" небходимо написать в форматах 1, 12, 123, 123А, 123/2, 123/2 А</span>
                        <input name="father_address-appartment" type="text" style="width: 200px;" placeholder="1" autocomplete="off" pattern="\d{1,3}"/>
                        <span class="form__error">Поле "Квартира" небходимо написать в форматах 1, 12, 123</span>
                    </div>
                    <div class="form__field">
                        <label for="father_address-mobilephone">Мобильный телефон</label><br>
                        <input type="text" name="father_address-mobilephone" placeholder="+375291234567" required pattern="[\+](375)\d{2}\d{7}" />
                        <span class="form__error">Поле "Мобильный телефон" небходимо написать в формате +375291234567</span>
                    </div>
                    <div class="form__field">
                        <label for="father_address-homephone">Домашний телефон</label><br>
                        <input type="text" name="father_address-homephone" placeholder="80162123456" pattern="(80)\d{3,4}\d{6}" />
                        <span class="form__error">Поле "Домашний телефон" небходимо написать в формате 80162123456</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="block" style="margin-top: 50px;">
            <b>Документ родителя (выберите, чей документ будет записан в договоре)</b>
            <div class="row">
                <div style="margin-right: 75px;">
                    <div class="row" style="margin-top: 15px;">
                        <div style="width: 200px; margin-right: 50px;">
                            <label>
                                <input type="radio" class="custom-radio" name="parent_document_mum_or_dad" checked value="mother" style="width: 15px; margin-top: 12px;">
                                матери
                            </label>
                            <label>
                                <input type="radio" class="custom-radio" name="parent_document_mum_or_dad" value="father" style="width: 15px; margin-top: 12px;">
                                отца
                            </label>
                        </div>
                        <div class="form__field">
                            <select name="parent_document" style="width: 245px;">
                                <option value="паспорт">паспорт</option>
                                <option value="вид на жительство">вид на жительство</option>
                                <option value="id card">id card</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form__field" style="width: 492px;">
                        <label for="parent_passport_serial">Серия (при наличии)</label>
                        <input name="parent_passport_serial" type="text" placeholder="КН" autocomplete="off" required pattern="[А-ЯA-Z]{2}" />
                        <span class="form__error">В поле "Серия" небходимо вписать две буквы номера документа (АВ, КН и т.д.)</span>
                    </div>
                    <div class="form__field" style="width: 492px;">
                        <label for="parent_passport_number">Номер</label>
                        <input name="parent_passport_number" type="text" placeholder="1234567" autocomplete="off" required pattern="\d{7}" />
                        <span class="form__error">В поле "Номер" небходимо вписать семь цифр номера документа (1234567)</span>
                    </div>
                </div>
                <div>
                    <div class="form__field">
                        <label for="parent_passport_when">Когда выдан</label><br>
                        <input name="parent_passport_when" type="text" placeholder="01.02.2020" autocomplete="off" required pattern="[0-3][0-9]\.[01][0-9]\.[12][90][0-9][0-9]" />
                        <span class="form__error">В поле "Когда выдан" небходимо вписать дату в формате ДД.ММ.ГГГГ</span>
                    </div>
                    <div class="form__field">
                    <label for="parent_passport_who">Кем выдан</label><br>
                        <input name="parent_passport_who" type="text" placeholder="Ленинским РОВД г.Бреста" required pattern="[а-яА-я\s\.]+" />
                        <span class="form__error">Поле "Кем выдан" небходимо заполнить русскими буквами</span>
                    </div>
                    <div class="form__field">
                        <label for="parent_passport_identifical">Идентификационный номер</label>
                        <input name="parent_passport_identifical" type="text" placeholder="1234567A001РВ1" autocomplete="off" required pattern="\d{7}[A-ZА-Я]{1}\d{3}[A-ZА-Я]{2}\d{1}" />
                        <span class="form__error">Поле "Идентификационный номер" небходимо написать в формате 1234567A001РВ1</span>
                    </div>
                </div>
            </div>
        </div>

        <div style="margin: 25px 50px 0 170px">
            <?php if ($_GET['payment'] == "за счет средств республиканского бюджета"): ?>
                <button type="submit" name="value_button" value="budjet" class='shine-button'>Подать на бюджет</button>
            <?php elseif ($_GET['payment'] == "all"): ?>
                <button type="submit" name="value_button" value="budjet_platnoe" class='shine-button'>Подать на бюджет + платное</button></p>
            <?php else: ?>
                <button type="submit" name="value_button" value="platnoe" class='shine-button'>Подать на платное</button></p>
            <?php endif; ?>
        </div>  
    </form>    